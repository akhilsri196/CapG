package conferenceRegister;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.Alert;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pom.structure.Browser;
import pom.structure.PaymentPageFactory;
import pom.structure.RegistrationPageFactory;

public class StepDefinitions {

	private RegistrationPageFactory register;
	private PaymentPageFactory payment;

	@Before
	public void setup() {
		Browser browser = new Browser();
		register = new RegistrationPageFactory(browser);
		payment = new PaymentPageFactory(browser);
	}

	@Given("^User is on ConferenceRegistration\\.html page$")
	public void user_is_on_ConferenceRegistration_html_page() throws Throwable {
		register.goTo();
	}

	@Then("^check the title of the registraion page$")
	public void check_the_title_of_the_registraion_page() throws Throwable {
		assertTrue(register.isAt());
	}

	@When("^user leaves FirstName blank$")
	public void user_leaves_FirstName_blank() throws Throwable {
		register.setFname("");
		Thread.sleep(1000);
	}

	@When("^clicks the Next button$")
	public void clicks_the_Next_button() throws Throwable {
		register.setNextbutton();
	}

	@Then("^display firstname alert msg$")
	public void display_firstname_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the First Name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);    //to wait atleast something is visible on screen
	}

	@When("^user leaves LastName blank$")
	public void user_leaves_LastName_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		
		register.setLname("");
	}

	@Then("^display lastname alert msg$")
	public void display_lastname_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Last Name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves Email blank$")
	public void user_leaves_Email_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setEmail("");
	}

	@Then("^display email alert msg$")
	public void display_email_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Email", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setArea("Talwade Chowk");
		Thread.sleep(1000);
		register.setBuilding("Siddhi HomeBase");
		Thread.sleep(1000);
		register.setCity("Pune");
		Thread.sleep(1000);
		register.setMobile("8790245678");
		Thread.sleep(1000);
		register.setRadioButton(1000);
		Thread.sleep(1000);
		register.setState("Maharashtra");
		Thread.sleep(1000);
		register.setPeopleAttending("3");
	}

	@When("^user enters incorrect email format$")
	public void user_enters_incorrect_email_format() throws Throwable {
		register.setEmail("a@com");
		Thread.sleep(1000);
	}

	@Then("^display wrong email format alert msg$")
	public void display_wrong_email_format_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please enter valid Email Id.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves MobileNo blank$")
	public void user_leaves_MobileNo_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setEmail("akki19@gmail.com");
		Thread.sleep(1000);
		register.setMobile("");
	}

	@Then("^display mobileNo alert msg$")
	public void display_mobileNo_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Contact No.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters incorrect mobileNo format$")
	public void user_enters_incorrect_mobileNo_format() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setEmail("akk2@gmail.com");
		Thread.sleep(1000);
		register.setMobile("876754");
	}

	@Then("^display wrong mobileNo alert msg$")
	public void display_wrong_mobileNo_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please enter valid Contact no.", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves People Attending blank$")
	public void user_leaves_People_Attending_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setEmail("akki19@gmail.com");
		Thread.sleep(1000);
		register.setMobile("8790245678");

	}

	@Then("^display People Attending alert msg$")
	public void display_People_Attending_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Number of people attending", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves BuildingName and RoomNo blank$")
	public void user_leaves_BuildingName_and_RoomNo_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setEmail("akki19@gmail.com");
		Thread.sleep(1000);
		register.setMobile("8790245678");
		Thread.sleep(1000);
		register.setPeopleAttending("3");
	}

	@Then("^display BuildingName alert msg$")
	public void display_BuildingName_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Building & Room No", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves AreaName blank$")
	public void user_leaves_AreaName_blank() throws Throwable {
		register.setFname("Akhil");
		Thread.sleep(1000);
		register.setLname("Srivastava");
		Thread.sleep(1000);
		register.setBuilding("build");
		Thread.sleep(1000);
		register.setEmail("akki19@gmail.com");
		register.setMobile("8790245678");
		Thread.sleep(1000);
		register.setPeopleAttending("3");
	}

	@Then("^display AreaName alert msg$")
	public void display_AreaName_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Area name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves City blank$")
	public void user_leaves_City_blank() throws Throwable {
		register.setFname("Akhil");
		register.setLname("Srivastava");
		register.setArea("ar");
		register.setBuilding("build");

		register.setEmail("akki19@gmail.com");
		register.setMobile("8790245678");
		register.setPeopleAttending("3");
	}

	@Then("^display City alert msg$")
	public void display_City_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please select city", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves State blank$")
	public void user_leaves_State_blank() throws Throwable {
		register.setFname("Akhil");
		register.setLname("Srivastava");
		register.setArea("ar");
		register.setBuilding("build");
		register.setCity("Pune");
		register.setEmail("akki19@gmail.com");
		register.setMobile("8790245678");

		register.setPeopleAttending("3");
	}

	@Then("^display State alert msg$")
	public void display_State_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please select state", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves Status blank$")
	public void user_leaves_Status_blank() throws Throwable {
		register.setFname("Akhil");
		register.setLname("Srivastava");
		register.setArea("ar");
		register.setBuilding("build");
		register.setCity("Pune");
		register.setEmail("akki19@gmail.com");
		register.setMobile("8790245678");
		register.setState("Maharashtra");
		register.setPeopleAttending("3");
	}

	@Then("^display Status alert msg$")
	public void display_Status_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please Select MemeberShip status", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all valid Registration data$")
	public void user_enters_all_valid_Registration_data() throws Throwable {
		register.setFname("Akhil");
		register.setLname("Srivastava");
		register.setArea("talwade");
		register.setBuilding("build");
		register.setCity("Pune");
		register.setEmail("akki19@gmail.com");
		register.setMobile("8790245678");
		register.setRadioButton(1000);
		register.setState("Maharashtra");
		register.setPeopleAttending("3");
	}

	@Then("^display success alert msg$")
	public void display_Success_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Conference Details are validated.", alert.getText());
		System.out.println(alert.getText());
		register.getBrowser().driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Then("^navigate to PaymentDetails\\.html page$")
	public void navigate_to_PaymentDetails_html_page() throws Throwable {
		payment.goTo();
		assertTrue(payment.isAt());
	}

	@Given("^User is on PaymentDetails\\.html page$")
	public void user_is_on_PaymentDetails_html_page() throws Throwable {
		payment.goTo();
	}

	@Then("^check the title of the Payment page$")
	public void check_the_title_of_the_Payment_page() throws Throwable {
		assertTrue(payment.isAt());
	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {

		payment.setCardholder("");
		Thread.sleep(1000);
		payment.setButton();
	}

	@Then("^display CardHolderName alert msg$")
	public void display_CardHolderName_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Card holder name", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		payment.setCardholder("Akhil");
		Thread.sleep(1000);
		payment.setDebit("");
		Thread.sleep(1000);
		payment.setButton();
	}

	@Then("^display DebitCardNo alert msg$")
	public void display_DebitCardNo_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the Debit card Number", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		payment.setCardholder("Akhil");
		Thread.sleep(1000);
		payment.setCvv("123");
		Thread.sleep(1000);
		payment.setDebit("121212121212");
		Thread.sleep(1000);
		payment.setMonth("");
		payment.setButton();
	}

	@Then("^display expirationMonth alert msg$")
	public void display_expirationMonth_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill expiration month", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		payment.setCardholder("Akhil");
		Thread.sleep(1000);
		payment.setCvv("123");
		payment.setDebit("121212121212");
		payment.setMonth("12");
		payment.setYear("");
		payment.setButton();
	}

	@Then("^display expirationYr alert msg$")
	public void display_expirationYr_alert_msg() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Please fill the expiration year", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@When("^user enters all valid Payment details and clicks the button$")
	public void user_enters_all_valid_Payment_details_and_clicks_the_button() throws Throwable {
		payment.setCardholder("Akhil");
		Thread.sleep(1000);
		payment.setCvv("123");
		Thread.sleep(1000);
		payment.setDebit("121212121212");
		Thread.sleep(1000);
		payment.setMonth("12");
		Thread.sleep(1000);
		payment.setYear("2026");
		Thread.sleep(1000);
		payment.setButton();
	}

	@Then("^check the alert message$")
	public void check_the_alert_message() throws Throwable {
		Alert alert = register.getBrowser().driver.switchTo().alert();
		assertEquals("Conference Room Booking successfully done!!!", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
	}

	@After
	public void exit() {
		register.getBrowser().close();
	}
}
