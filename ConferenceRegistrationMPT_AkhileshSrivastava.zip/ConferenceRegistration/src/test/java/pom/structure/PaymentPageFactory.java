package pom.structure;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class PaymentPageFactory extends PathPages {

	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardholder;

	@FindBy(id = "txtDebit")
	@CacheLookup
	WebElement debit;

	@FindBy(id = "txtCvv")
	@CacheLookup
	WebElement cvv;

	@FindBy(id = "txtMonth")
	@CacheLookup
	WebElement month;

	@FindBy(id = "txtYear")
	@CacheLookup
	WebElement year;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement button;

	private static String page = "PaymentDetails.html";
	private static String title = "Payment Details";

	 public PaymentPageFactory(Browser browser) {
		super(page, title, browser);
		PageFactory.initElements(super.getBrowser().driver, this);
	}

	@Override
	public Browser getBrowser() {
		return super.getBrowser();
	}
	
	public WebElement getCardholder() {
		return cardholder;
	}

	public void setCardholder(String holder) {
		cardholder.sendKeys(holder);
	}

	public WebElement getDebit() {
		return debit;
	}

	public void setDebit(String deb) {
		debit.sendKeys(deb);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cv) {
		cvv.sendKeys(cv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String mo) {
		month.sendKeys(mo);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String y) {
		year.sendKeys(y);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
	
	
	
	
}
