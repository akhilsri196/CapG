package com.demo.car.service;

import java.util.List;

import com.demo.car.bean.CarDTO;


public interface ICarDTOservice
{    
	
	public List<CarDTO> findAll(); 
public CarDTO findById(int id);
public boolean create(CarDTO car);
public boolean update(CarDTO car);
public boolean delete(int ids);


}
