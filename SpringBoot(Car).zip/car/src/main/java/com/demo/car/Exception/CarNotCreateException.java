package com.demo.car.Exception;

public class CarNotCreateException extends RuntimeException
{

}
