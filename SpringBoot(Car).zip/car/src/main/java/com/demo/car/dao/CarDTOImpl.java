package com.demo.car.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.demo.car.Exception.CarNotCreateException;
import com.demo.car.bean.CarDTO;
    
@Repository

public class CarDTOImpl implements ICarDTO 
{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<CarDTO> findAll() 
	{
		Query query=entityManager.createQuery
				("select carDTO from CarDTO carDTO ");
						
					List<CarDTO> list= query.getResultList();
				return list;
		
		// TODO Auto-generated method stub
	
	}

	@Override
	public CarDTO findById(int id)
	{
		

		CarDTO cardto= 
				entityManager.find(CarDTO.class, id);
		if(cardto==null)
			throw new CarNotCreateException();
		
		return cardto;
		
		// TODO Auto-generated method stub
	
	}

	@Override
	public boolean create(CarDTO car)
	{
		

		entityManager.persist(car);
		
		
		
		return true;
	
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean update(CarDTO car)
	{
		entityManager.merge(car);
	entityManager.close();
	return true;
		// TODO Auto-generated method stub
	
	}

	@Override
	public boolean delete(int ids)
	{
		CarDTO cardto= entityManager.find(CarDTO.class,ids);
		entityManager.remove(cardto);
		entityManager.flush();
		return true;
		
		// TODO Auto-generated method stub
	
	}

}
