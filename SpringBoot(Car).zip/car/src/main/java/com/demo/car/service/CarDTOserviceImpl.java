package com.demo.car.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.car.bean.CarDTO;
import com.demo.car.dao.ICarDTO;
@Transactional
@Service


public class CarDTOserviceImpl  implements  ICarDTOservice
{
	@Autowired
	ICarDTO cardtoref;


	@Override
	public List<CarDTO> findAll() 
	{
		// TODO Auto-generated method stub
		return cardtoref.findAll();
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return cardtoref.findById(id);
	}

	@Override
	public boolean create(CarDTO car) 
	{
		// TODO Auto-generated method stub
		return cardtoref.create(car);
	}

	@Override
	public boolean update(CarDTO car) {
		// TODO Auto-generated method stub
		return cardtoref.update(car);
	}

	@Override
	public boolean delete(int ids) {
		// TODO Auto-generated method stub
		return cardtoref.delete(ids);
	}
}

	


