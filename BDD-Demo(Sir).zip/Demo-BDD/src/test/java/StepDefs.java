import static org.junit.Assert.assertEquals;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

	private int[] arr=new int[2];
	private int  count;
	private int result;
	
	@Given("^I have entered (\\d+) in the calculator$")
	public void i_have_entered_in_the_calculator(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		arr[count++]=arg1;
		
	}

	@When("^I press add$")
	public void i_press_add() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		result=arr[0]+arr[1];
	}

	@Then("^It should display (\\d+) on the screen$")
	public void it_should_display_on_the_screen(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		assertEquals(arg1, result);
	}

}
