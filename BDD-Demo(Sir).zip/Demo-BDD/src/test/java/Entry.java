import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Entry {

	public static void main(String[] args) {
		
		
		System.out.println("Working Directory = "+System.getProperty("user.dir"));
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		
		//optional
		ChromeOptions chrome_options=new ChromeOptions();
		chrome_options.setExperimentalOption("useAutomationExtension", false);
		chrome_options.addArguments("-no-sandbox");
		chrome_options.addArguments("-disable-dev-shm-usage");
		
		WebDriver driver=new ChromeDriver(chrome_options);
		driver.get("http://www.google.com");
		//driver.get("file:////D:/softwares/New folder/Sir Demos/BDD/Cucumber-Selenium-POM-Demo/scr/main/webapp/RadioButtonTest.html");
		WebElement searchField=driver.findElement(By.name("q"));
		searchField.sendKeys("Mercury");
		searchField.submit();		
	}
	
}
