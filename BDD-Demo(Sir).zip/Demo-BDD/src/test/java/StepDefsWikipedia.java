import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefsWikipedia {
	WebElement searchField;
	WebDriver driver;
	
	@Before
	public void setup()
	{
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver=new ChromeDriver();	
		driver.navigate().to("http://en.wikipedia.org");
	}
	@Given("^Enter Search Term '(.*)'$")
	public void enter_Search_Term(String arg1) throws Exception {
	    searchField=driver.findElement(By.id("searchInput"));
		searchField.sendKeys(arg1);		
	}

	@When("^Do Search$")
	public void do_Search() throws Exception {
		searchField.submit();	
	}

	@Then("^Then Multiple results are shown for '(.*)'$")
	public void then_Multiple_results_are_shown_for(String arg1) throws Exception {
	    searchField=driver.findElement(By.id("firstHeading"));
		String s=searchField.getText();
		assertEquals(arg1, s);
	}
	
	@After
	public void tearDown()
	{
		driver.quit();
	}


}
	
