$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/DemoFeature.feature");
formatter.feature({
  "name": "Demo Feature Just for learning",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Add Two Numbers",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "I have entered 20 in the calculator",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefs.i_have_entered_in_the_calculator(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I have entered 50 in the calculator",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.i_have_entered_in_the_calculator(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I press add",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefs.i_press_add()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "It should display 70 on the screen",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefs.it_should_display_on_the_screen(int)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/test/resources/WikepediaTest.feature");
formatter.feature({
  "name": "test Wikepdia",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Enter Search Term \u0027\u003csearchTerm\u003e\u0027",
  "keyword": "Given "
});
formatter.step({
  "name": "Do Search",
  "keyword": "When "
});
formatter.step({
  "name": "Then Multiple results are shown for \u0027\u003cresult\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "searchTerm",
        "result"
      ]
    },
    {
      "cells": [
        "Mercury",
        "Mercury"
      ]
    },
    {
      "cells": [
        "Max",
        "Max"
      ]
    }
  ]
});
formatter.scenario({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter Search Term \u0027Mercury\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefsWikipedia.enter_Search_Term(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Do Search",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefsWikipedia.do_Search()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Then Multiple results are shown for \u0027Mercury\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefsWikipedia.then_Multiple_results_are_shown_for(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter Search Term \u0027Max\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefsWikipedia.enter_Search_Term(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Do Search",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefsWikipedia.do_Search()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Then Multiple results are shown for \u0027Max\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefsWikipedia.then_Multiple_results_are_shown_for(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});