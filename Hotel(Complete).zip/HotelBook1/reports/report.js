$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("ResetDataTable.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    }
  ],
  "line": 3,
  "name": "Reset functionality on login page of Application",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Verification of reset button with numbers of credentials",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Open the Firefox and launch the application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the Username \u0027\u003cusername\u003e\u0027 and Password \u0027\u003cpassword\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Reset the credential",
  "keyword": "Then "
});
formatter.examples({
  "line": 8,
  "name": "",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 9,
      "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;1"
    },
    {
      "cells": [
        "User11",
        "password11"
      ],
      "line": 10,
      "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;2"
    },
    {
      "cells": [
        "User22",
        "password22"
      ],
      "line": 11,
      "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;3"
    },
    {
      "cells": [
        "User33",
        "password33"
      ],
      "line": 12,
      "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 10,
  "name": "Verification of reset button with numbers of credentials",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Open the Firefox and launch the application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the Username \u0027User11\u0027 and Password \u0027password11\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Reset the credential",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.open_the_Firefox_and_launch_the_application()"
});
formatter.result({
  "duration": 4315817130,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "11",
      "offset": 24
    },
    {
      "val": "11",
      "offset": 50
    }
  ],
  "location": "StepDef.enter_the_Username_User_and_Password_password(int,int)"
});
formatter.result({
  "duration": 2522650882,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.reset_the_credential()"
});
formatter.result({
  "duration": 93995515,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Verification of reset button with numbers of credentials",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Open the Firefox and launch the application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the Username \u0027User22\u0027 and Password \u0027password22\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Reset the credential",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.open_the_Firefox_and_launch_the_application()"
});
formatter.result({
  "duration": 2817278097,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22",
      "offset": 24
    },
    {
      "val": "22",
      "offset": 50
    }
  ],
  "location": "StepDef.enter_the_Username_User_and_Password_password(int,int)"
});
formatter.result({
  "duration": 2232648778,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.reset_the_credential()"
});
formatter.result({
  "duration": 96483828,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Verification of reset button with numbers of credentials",
  "description": "",
  "id": "reset-functionality-on-login-page-of-application;verification-of-reset-button-with-numbers-of-credentials;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Open the Firefox and launch the application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the Username \u0027User33\u0027 and Password \u0027password33\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Reset the credential",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.open_the_Firefox_and_launch_the_application()"
});
formatter.result({
  "duration": 3129163908,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "33",
      "offset": 24
    },
    {
      "val": "33",
      "offset": 50
    }
  ],
  "location": "StepDef.enter_the_Username_User_and_Password_password(int,int)"
});
formatter.result({
  "duration": 2316782384,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.reset_the_credential()"
});
formatter.result({
  "duration": 106380118,
  "status": "passed"
});
});