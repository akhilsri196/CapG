package com.example.TDD.repo;

import java.util.List;

import com.example.TDD.dto.CarDTO;


public interface CarDAO 
{
    public List<CarDTO> findAll(); 
    public CarDTO findById(int id);
    public void create(CarDTO car);
    public void update(CarDTO car);
    public void delete(String[] ids);
}