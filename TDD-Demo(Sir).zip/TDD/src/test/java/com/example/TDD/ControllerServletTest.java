package com.example.TDD;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.TDD.dto.CarDTO;
import com.example.TDD.repo.CarDAO;

@RunWith(MockitoJUnitRunner.class)
public class ControllerServletTest {


	@Mock
	private CarDAO carDAO;

    @Mock
	private HttpServletRequest request;
    
	@Mock
    private HttpServletResponse response;
	
	@InjectMocks
	private ControllerServlet myService;
	
	@Test
	public void testProcessRequest() throws ServletException, IOException {
     //Setup
	//Stubbing (Aisa ho to aisa miley)
	Mockito.when(request.getParameter("action")).thenReturn("viewCarList");
	List<CarDTO> cars=new LinkedList<CarDTO>();
	CarDTO car=new CarDTO();
	car.setId(1);
	car.setMake("Honda");
	car.setModel("Amaze");
	car.setModelYear("2018");
	cars.add(car);
	CarDTO car2=new CarDTO();
	car2.setId(2);
	car2.setMake("Wolkswagen");
	car2.setModel("Polo");
	car2.setModelYear("2014");
	cars.add(car);
	Mockito.when(carDAO.findAll()).thenReturn(cars);
	
	//Execution
	myService.processRequest(request, response);
	
	//Verification
	Mockito.verify(request).getParameter("action");
	Mockito.verify(carDAO).findAll();
	
	//Edit Car
	Mockito.when(request.getParameter("action")).thenReturn("editCar");
	Mockito.when(request.getParameter("id")).thenReturn("1");
	Mockito.when(carDAO.findById(1)).thenReturn(car);
	myService.processRequest(request, response);
	Mockito.verify(carDAO).findById(1);
	
/*	//Delete Car
	Mockito.when(request.getParameter("action")).thenReturn("deleteCar");
	String[] ar= {"1","2"};
	Mockito.when(request.getParameterValues("id")).thenReturn(ar);
	//Mockito.verify(carDAO).delete(ar);
	*/
	}

}
