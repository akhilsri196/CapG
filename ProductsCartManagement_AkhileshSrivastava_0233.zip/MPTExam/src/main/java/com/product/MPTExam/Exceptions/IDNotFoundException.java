package com.product.MPTExam.Exceptions;

public class IDNotFoundException extends RuntimeException {

	 public IDNotFoundException() {
		 System.out.println("Id You Entered is not present in our database");
	 }
	
}
