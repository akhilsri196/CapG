package com.product.MPTExam.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Repository.IProductRepo;

@Transactional
@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo daoref;

	@Override
	public ProductDTO create(ProductDTO product) {

		return daoref.create(product);
	}

	@Override
	public ProductDTO update(String id, ProductDTO product) {

		return daoref.update(id, product);
	}

	@Override
	public ProductDTO delete(String id) {

		return daoref.delete(id);
	}

	@Override
	public List<ProductDTO> viewProducts() {
		return daoref.viewProducts();
	}

	@Override
	public ProductDTO findProduct(String id) {
		ProductDTO p = daoref.findProduct(id);
		return p;
	}

}
