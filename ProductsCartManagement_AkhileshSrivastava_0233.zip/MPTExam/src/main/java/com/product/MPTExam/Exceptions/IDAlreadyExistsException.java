package com.product.MPTExam.Exceptions;

public class IDAlreadyExistsException extends RuntimeException {
public IDAlreadyExistsException() {
System.out.println("Id You Entered is Already present in the Database");
}
}
