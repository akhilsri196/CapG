package com.product.MPTExam.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Exceptions.IDAlreadyExistsException;
import com.product.MPTExam.Exceptions.IDNotFoundException;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo { // Test cases for this class are written in src/test/java

	@PersistenceContext
	EntityManager em;

	@Transactional
	@Override
	public ProductDTO create(ProductDTO product) {

		ProductDTO p = (ProductDTO) em.find(ProductDTO.class, product.getId());
		if (p == null) {
			em.persist(product);
			return product;
		}
		throw new IDAlreadyExistsException(); // If Some data with same ID Exists Then Exception will be thrown
	}

	@Override
	public ProductDTO update(String id, ProductDTO product) {
		em.merge(product);
		return product;
	}

	@Override
	public ProductDTO delete(String id) { // If user enter a wrong ID which is not present in the database Then
											// Exception will be thrown

		ProductDTO p = (ProductDTO) em.find(ProductDTO.class, id);
		if (p != null) {
			em.remove(p);
			return p;
		}
		throw new IDNotFoundException();
	}

	@Override
	public List<ProductDTO> viewProducts() {
		Query query = em.createQuery("select p from ProductDTO p");
		return query.getResultList();
	}

	@Override
	public ProductDTO findProduct(String id) {

		ProductDTO p = (ProductDTO) em.find(ProductDTO.class, id);
		if (p != null)
			return p;
		throw new IDNotFoundException();
	}

}
