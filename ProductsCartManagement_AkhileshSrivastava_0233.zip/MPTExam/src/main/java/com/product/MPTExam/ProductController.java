package com.product.MPTExam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Exceptions.IDAlreadyExistsException;
import com.product.MPTExam.Exceptions.IDNotFoundException;
import com.product.MPTExam.Service.IProductService;

@RestController
@RequestMapping("/products") // I have use port 8050
public class ProductController {

	@Autowired
	IProductService serRef;

	@RequestMapping(method = RequestMethod.GET) // User hits Get Request
	public List<ProductDTO> list() {
		return serRef.viewProducts();
	}

	@RequestMapping(method = RequestMethod.POST) // User hits Post Request
	public ProductDTO create(@RequestBody ProductDTO product) {
		return serRef.create(product);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}") // User hits Put Request for updation
	public ProductDTO update(@RequestBody ProductDTO product, @PathVariable(name = "id") String id) {
		return serRef.update(id, product);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{id}") // User hits Delete Request
	public ProductDTO delete(@PathVariable(name = "id") String id) {
		return serRef.delete(id);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{id}") // User hits Get Request to find product By Id
	public ProductDTO findBy(@PathVariable(name = "id") String id) {
		return serRef.findProduct(id);
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "You have Entered an Invalid ID")
	@ExceptionHandler({ IDNotFoundException.class })
	public void HandleIDNotPresent() // This method will handle the Exception if user enters a wrong ID to find
										// product or to delete product
	{

	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Id you entered already exists in the Database")
	@ExceptionHandler({ IDAlreadyExistsException.class }) // This method will handle the Exception if user enters a same
															// ID which is already present
	public void IdAlreadyExists() {

	}

}
