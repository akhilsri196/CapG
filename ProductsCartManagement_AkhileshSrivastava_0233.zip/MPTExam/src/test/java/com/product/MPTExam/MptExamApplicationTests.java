package com.product.MPTExam;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Repository.IProductRepo;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MptExamApplicationTests {

	@Autowired
	IProductRepo daoRef;

	@Test
	public void testFindById() {
		ProductDTO p = daoRef.findProduct("s01"); //Product name with id=s01 is Samsung
		assertTrue(p.getName().equals("Samsung"));
	}

	@Test
	public void testGetAllProducts() {      //When I created this test case there were only three products
		List<ProductDTO> list = daoRef.viewProducts();
		assertEquals(3, list.size());
	}

}
